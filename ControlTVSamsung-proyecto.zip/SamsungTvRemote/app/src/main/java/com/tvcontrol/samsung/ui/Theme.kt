package com.tvcontrol.samsung.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = darkColorScheme(
    primary = Color(0xFF4FA3FF),
    onPrimary = Color(0xFF00213F),
    secondary = Color(0xFF8AB4F8),
    background = Color(0xFF0B0E13),
    onBackground = Color(0xFFE6E8EC),
    surface = Color(0xFF141922),
    onSurface = Color(0xFFE6E8EC),
    surfaceVariant = Color(0xFF222A36),
    onSurfaceVariant = Color(0xFFB9C0CC),
    error = Color(0xFFFF6B6B),
)

@Composable
fun TvTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
