package com.tvcontrol.samsung.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcontrol.samsung.TvViewModel
import com.tvcontrol.samsung.net.Keys
import kotlin.math.abs

@Composable
fun RemoteScreen(vm: TvViewModel, modifier: Modifier = Modifier) {
    val state by vm.connState.collectAsStateWithLifecycle()
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ConnectionBanner(vm, state)

        // Encendido y entradas
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton(
                "⏻", Modifier.weight(1f),
                container = Color(0xFFB3261E), content = Color.White, fontSize = 22.sp,
            ) { vm.powerToggle() }
            KeyButton("Fuente", Modifier.weight(1f)) { vm.key(Keys.SOURCE) }
            KeyButton("HDMI", Modifier.weight(1f)) { vm.key(Keys.HDMI) }
            KeyButton("TV", Modifier.weight(1f)) { vm.key(Keys.TV) }
        }

        DPad(vm)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("↩ Atrás", Modifier.weight(1f)) { vm.key(Keys.RETURN) }
            KeyButton("⌂ Inicio", Modifier.weight(1f)) { vm.key(Keys.HOME) }
            KeyButton("Salir", Modifier.weight(1f)) { vm.key(Keys.EXIT) }
        }

        // Volumen y canales
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RockerPanel(
                modifier = Modifier.weight(1f),
                title = "VOL",
                up = { vm.key(Keys.VOL_UP) },
                down = { vm.key(Keys.VOL_DOWN) },
                middleLabel = "🔇",
                middle = { vm.key(Keys.MUTE) },
            )
            RockerPanel(
                modifier = Modifier.weight(1f),
                title = "CH",
                up = { vm.key(Keys.CH_UP) },
                down = { vm.key(Keys.CH_DOWN) },
                middleLabel = "Lista",
                middle = { vm.key(Keys.CH_LIST) },
            )
        }

        SectionTitle("MENÚS")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("Menú", Modifier.weight(1f)) { vm.key(Keys.MENU) }
            KeyButton("Info", Modifier.weight(1f)) { vm.key(Keys.INFO) }
            KeyButton("Guía", Modifier.weight(1f)) { vm.key(Keys.GUIDE) }
            KeyButton("Tools", Modifier.weight(1f)) { vm.key(Keys.TOOLS) }
        }

        SectionTitle("REPRODUCCIÓN")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("⏪", Modifier.weight(1f), fontSize = 18.sp) { vm.key(Keys.REWIND) }
            KeyButton("▶", Modifier.weight(1f), fontSize = 18.sp) { vm.key(Keys.PLAY) }
            KeyButton("⏸", Modifier.weight(1f), fontSize = 18.sp) { vm.key(Keys.PAUSE) }
            KeyButton("⏹", Modifier.weight(1f), fontSize = 18.sp) { vm.key(Keys.STOP) }
            KeyButton("⏩", Modifier.weight(1f), fontSize = 18.sp) { vm.key(Keys.FF) }
            KeyButton("⏺", Modifier.weight(1f), fontSize = 18.sp, content = Color(0xFFFF6B6B)) { vm.key(Keys.REC) }
        }

        SectionTitle("TECLAS DE COLOR")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("", Modifier.weight(1f), container = Color(0xFFD32F2F)) { vm.key(Keys.RED) }
            KeyButton("", Modifier.weight(1f), container = Color(0xFF2E7D32)) { vm.key(Keys.GREEN) }
            KeyButton("", Modifier.weight(1f), container = Color(0xFFF9A825)) { vm.key(Keys.YELLOW) }
            KeyButton("", Modifier.weight(1f), container = Color(0xFF1976D2)) { vm.key(Keys.BLUE) }
        }

        SectionTitle("NÚMEROS")
        NumberPad(vm)

        SectionTitle("OTROS")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("Apps", Modifier.weight(1f)) { vm.key(Keys.APP_LIST) }
            KeyButton("Apagado auto.", Modifier.weight(1f)) { vm.key(Keys.SLEEP) }
            KeyButton("Tamaño imagen", Modifier.weight(1f)) { vm.key(Keys.PICTURE_SIZE) }
        }

        SectionTitle("PANEL TÁCTIL")
        TouchPad(vm)

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun DPad(vm: TvViewModel) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.weight(1f))
            KeyButton("▲", Modifier.weight(1f).height(64.dp), repeat = true, fontSize = 22.sp) { vm.key(Keys.UP) }
            Spacer(Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("◀", Modifier.weight(1f).height(64.dp), repeat = true, fontSize = 22.sp) { vm.key(Keys.LEFT) }
            KeyButton(
                "OK", Modifier.weight(1f).height(64.dp),
                container = MaterialTheme.colorScheme.primary,
                content = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape, fontSize = 20.sp,
            ) { vm.key(Keys.ENTER) }
            KeyButton("▶", Modifier.weight(1f).height(64.dp), repeat = true, fontSize = 22.sp) { vm.key(Keys.RIGHT) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.weight(1f))
            KeyButton("▼", Modifier.weight(1f).height(64.dp), repeat = true, fontSize = 22.sp) { vm.key(Keys.DOWN) }
            Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun RockerPanel(
    modifier: Modifier,
    title: String,
    up: () -> Unit,
    down: () -> Unit,
    middleLabel: String,
    middle: () -> Unit,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        KeyButton("＋", Modifier.fillMaxWidth().height(60.dp), repeat = true, fontSize = 22.sp, onKey = up)
        KeyButton(middleLabel, Modifier.fillMaxWidth(), fontSize = 14.sp, onKey = middle)
        Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        KeyButton("－", Modifier.fillMaxWidth().height(60.dp), repeat = true, fontSize = 22.sp, onKey = down)
    }
}

@Composable
private fun NumberPad(vm: TvViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9")).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { digit ->
                    KeyButton(digit, Modifier.weight(1f), fontSize = 18.sp) { vm.key("KEY_$digit") }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KeyButton("Anterior", Modifier.weight(1f)) { vm.key(Keys.PRE_CH) }
            KeyButton("0", Modifier.weight(1f), fontSize = 18.sp) { vm.key("KEY_0") }
            KeyButton("Subtít.", Modifier.weight(1f)) { vm.key(Keys.CAPTION) }
        }
    }
}

@Composable
private fun TouchPad(vm: TvViewModel) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { vm.key(Keys.ENTER) })
            }
            .pointerInput(Unit) {
                var accX = 0f
                var accY = 0f
                val step = 70f
                detectDragGestures(
                    onDragStart = {
                        accX = 0f
                        accY = 0f
                    },
                ) { change, drag ->
                    change.consume()
                    accX += drag.x
                    accY += drag.y
                    if (abs(accX) > step || abs(accY) > step) {
                        val key = if (abs(accX) > abs(accY)) {
                            if (accX > 0) Keys.RIGHT else Keys.LEFT
                        } else {
                            if (accY > 0) Keys.DOWN else Keys.UP
                        }
                        vm.key(key)
                        accX = 0f
                        accY = 0f
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "Desliza para moverte · toca para OK",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
        )
    }
}
