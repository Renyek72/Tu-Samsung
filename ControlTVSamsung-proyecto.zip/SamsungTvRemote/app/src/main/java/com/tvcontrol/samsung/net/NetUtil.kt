package com.tvcontrol.samsung.net

import android.content.Context
import android.net.ConnectivityManager
import java.net.Inet4Address
import java.net.NetworkInterface

object NetUtil {

    data class LocalNet(val ip: String, val prefix: Int)

    /** Dirección IPv4 local del teléfono en la red activa (Wi-Fi normalmente). */
    fun localIpv4(context: Context): LocalNet? {
        val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java)
        val network = cm?.activeNetwork
        val props = if (network != null) cm.getLinkProperties(network) else null
        if (props != null) {
            for (linkAddress in props.linkAddresses) {
                val address = linkAddress.address
                if (address is Inet4Address && !address.isLoopbackAddress) {
                    val host = address.hostAddress
                    if (host != null) return LocalNet(host, linkAddress.prefixLength)
                }
            }
        }
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.interfaceAddresses }
                .firstOrNull { it.address is Inet4Address }
                ?.let { LocalNet(it.address.hostAddress ?: return@let null, it.networkPrefixLength.toInt()) }
        } catch (e: Exception) {
            null
        }
    }
}
