package com.tvcontrol.samsung.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.tvcontrol.samsung.TvViewModel
import kotlinx.coroutines.launch

private val Tabs = listOf(
    "Control" to "🎛️",
    "Apps" to "📺",
    "Pantalla" to "📱",
    "Conexión" to "⚙️",
)

@Composable
fun TvApp(
    vm: TvViewModel,
    onStartMirror: () -> Unit,
    onStopMirror: () -> Unit,
    onOpenCast: () -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.messages.collect { message ->
            snackbar.currentSnackbarData?.dismiss()
            launch { snackbar.showSnackbar(message) }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                Tabs.forEachIndexed { index, (title, icon) ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Text(icon) },
                        label = { Text(title) },
                    )
                }
            }
        },
    ) { inner ->
        val content = Modifier.padding(inner)
        when (tab) {
            0 -> RemoteScreen(vm, content)
            1 -> AppsScreen(vm, content)
            2 -> MirrorScreen(vm, onStartMirror, onStopMirror, onOpenCast, content)
            else -> ConnectionScreen(vm, content)
        }
    }
}
