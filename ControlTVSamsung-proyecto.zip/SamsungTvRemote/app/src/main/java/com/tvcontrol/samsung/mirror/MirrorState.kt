package com.tvcontrol.samsung.mirror

import kotlinx.coroutines.flow.MutableStateFlow

sealed interface MirrorStatus {
    data object Idle : MirrorStatus
    data object Starting : MirrorStatus
    data class Streaming(val url: String) : MirrorStatus
    data class Failed(val message: String) : MirrorStatus
}

/** Estado compartido entre el servicio de captura y la interfaz. */
object MirrorState {
    val status = MutableStateFlow<MirrorStatus>(MirrorStatus.Idle)
}
