package com.tvcontrol.samsung.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvcontrol.samsung.TvViewModel
import com.tvcontrol.samsung.net.ConnState
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Botón de control remoto: vibra al tocar y, con [repeat], repite mientras se mantiene pulsado. */
@Composable
fun KeyButton(
    label: String,
    modifier: Modifier = Modifier,
    container: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: Color = MaterialTheme.colorScheme.onSurface,
    shape: Shape = RoundedCornerShape(14.dp),
    repeat: Boolean = false,
    fontSize: TextUnit = 15.sp,
    onKey: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val currentOnKey by rememberUpdatedState(onKey)
    var pressed by remember { mutableStateOf(false) }
    Box(
        modifier = modifier
            .heightIn(min = 52.dp)
            .clip(shape)
            .background(if (pressed) container.copy(alpha = 0.55f) else container)
            .pointerInput(repeat) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        currentOnKey()
                        if (repeat) {
                            coroutineScope {
                                val job = launch {
                                    delay(450)
                                    while (true) {
                                        currentOnKey()
                                        delay(110)
                                    }
                                }
                                tryAwaitRelease()
                                job.cancel()
                            }
                        } else {
                            tryAwaitRelease()
                        }
                        pressed = false
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = content,
            fontSize = fontSize,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 4.dp),
    )
}

/** Franja de estado de la conexión con la TV, con acción de conectar/reintentar. */
@Composable
fun ConnectionBanner(vm: TvViewModel, state: ConnState) {
    val (color, text) = when (state) {
        is ConnState.Connected -> Color(0xFF3DDC84) to "Conectado${if (vm.tvName.isNotBlank()) " · ${vm.tvName}" else ""}"
        is ConnState.Connecting -> Color(0xFFFFC107) to "Conectando con la TV…"
        is ConnState.WaitingApproval -> Color(0xFFFFC107) to "Acepta el aviso que apareció en la pantalla de la TV"
        is ConnState.Disconnected -> Color(0xFF9AA0A6) to "Sin conexión"
        is ConnState.Error -> Color(0xFFFF6B6B) to state.message
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Column(Modifier.weight(1f)) {
            Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        if (state !is ConnState.Connected && state !is ConnState.Connecting && state !is ConnState.WaitingApproval) {
            OutlinedButton(onClick = { vm.connect() }) { Text("Conectar") }
        }
    }
}
