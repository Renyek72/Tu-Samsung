package com.tvcontrol.samsung

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tvcontrol.samsung.data.TvPrefs
import com.tvcontrol.samsung.mirror.MirrorState
import com.tvcontrol.samsung.mirror.MirrorStatus
import com.tvcontrol.samsung.net.ConnState
import com.tvcontrol.samsung.net.Keys
import com.tvcontrol.samsung.net.SamsungTvClient
import com.tvcontrol.samsung.net.TvDiscovery
import com.tvcontrol.samsung.net.TvInfo
import com.tvcontrol.samsung.net.WakeOnLan
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

class TvViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = TvPrefs(app)
    private val client = SamsungTvClient()
    private val discovery = TvDiscovery(app, client)

    val connState: StateFlow<ConnState> = client.state
    val mirrorStatus: StateFlow<MirrorStatus> = MirrorState.status

    var ip by mutableStateOf(prefs.ip)
        private set
    var mac by mutableStateOf(prefs.mac)
        private set
    var tvName by mutableStateOf(prefs.name)
        private set
    var hasToken by mutableStateOf(prefs.token.isNotEmpty())
        private set
    var scanning by mutableStateOf(false)
        private set
    var poweringOn by mutableStateOf(false)
        private set

    val found = mutableStateListOf<TvInfo>()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        client.onToken = { token ->
            prefs.token = token
            viewModelScope.launch { hasToken = true }
        }
        if (prefs.ip.isNotBlank()) connect()
    }

    fun say(text: String) {
        _messages.tryEmit(text)
    }

    fun setIp(value: String) {
        ip = value.trim()
        prefs.ip = ip
    }

    fun setMac(value: String) {
        mac = value.trim()
        prefs.mac = mac
    }

    fun connect() {
        if (ip.isBlank()) {
            say("Primero escribe la IP de la TV o pulsa «Buscar TV».")
            return
        }
        client.connect(ip, prefs.token.ifEmpty { null })
        viewModelScope.launch {
            client.fetchInfo(ip)?.let { applyInfo(it) }
        }
    }

    fun disconnect() = client.disconnect()

    fun forgetPairing() {
        prefs.token = ""
        hasToken = false
        client.disconnect()
        say("Emparejamiento olvidado. Al conectar de nuevo, la TV pedirá confirmación.")
    }

    private fun applyInfo(info: TvInfo) {
        if (info.name.isNotBlank()) {
            tvName = info.name
            prefs.name = info.name
        }
        if (info.wifiMac.isNotBlank() && mac.isBlank()) {
            mac = info.wifiMac
            prefs.mac = info.wifiMac
        }
    }

    private fun notConnectedMessage(): String =
        if (connState.value is ConnState.Connected) "No se pudo enviar el comando." else "Sin conexión con la TV. Ve a «Conexión» y pulsa Conectar."

    fun key(code: String) {
        if (!client.sendKey(code)) say(notConnectedMessage())
    }

    fun sendText(text: String) {
        if (text.isEmpty()) return
        if (!client.sendText(text)) say(notConnectedMessage())
    }

    fun launchApp(appId: String) {
        if (ip.isBlank()) {
            say("Primero configura la TV en «Conexión».")
            return
        }
        viewModelScope.launch {
            val ok = client.launchApp(ip, appId.trim())
            say(if (ok) "Abriendo la app en la TV…" else "La TV no pudo abrir esa app (¿está instalada? ¿está encendida?).")
        }
    }

    fun scan() {
        if (scanning) return
        scanning = true
        found.clear()
        viewModelScope.launch {
            val result = try {
                discovery.scan()
            } catch (e: Exception) {
                emptyList()
            }
            found.addAll(result)
            scanning = false
            when (result.size) {
                0 -> say("No encontré ninguna TV Samsung. Revisa que esté encendida y en la misma red Wi-Fi, o escribe la IP a mano.")
                1 -> select(result[0])
                else -> say("Encontré ${result.size} TVs. Elige una de la lista.")
            }
        }
    }

    fun select(info: TvInfo) {
        if (info.ip != ip) {
            prefs.token = ""
            hasToken = false
            mac = ""
            prefs.mac = ""
        }
        ip = info.ip
        prefs.ip = info.ip
        applyInfo(info)
        connect()
    }

    /** Conectada → alterna encendido/apagado. Sin conexión → intenta encenderla por Wake-on-LAN. */
    fun powerToggle() {
        if (connState.value is ConnState.Connected) {
            key(Keys.POWER)
            return
        }
        if (poweringOn) return
        viewModelScope.launch {
            poweringOn = true
            try {
                if (ip.isBlank()) {
                    say("Primero configura la TV en «Conexión».")
                    return@launch
                }
                if (mac.isBlank()) client.fetchInfo(ip)?.let { applyInfo(it) }
                if (mac.isBlank()) {
                    say("Para encender la TV necesito su dirección MAC. Conéctala una vez con la TV encendida o escríbela en «Conexión».")
                    return@launch
                }
                say("Enviando señal de encendido (Wake-on-LAN)…")
                WakeOnLan.send(mac, ip)
                repeat(12) {
                    delay(2500)
                    val info = client.fetchInfo(ip)
                    if (info != null && info.powerState.equals("on", ignoreCase = true)) {
                        connect()
                        return@launch
                    }
                    WakeOnLan.send(mac, ip)
                }
                say("La TV no respondió. Activa «Encender con móvil» en Ajustes > General > Red > Configuración de experto, y comprueba la MAC.")
            } finally {
                poweringOn = false
            }
        }
    }

    override fun onCleared() {
        client.disconnect()
        super.onCleared()
    }
}
