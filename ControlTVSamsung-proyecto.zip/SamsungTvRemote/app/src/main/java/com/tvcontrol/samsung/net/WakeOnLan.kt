package com.tvcontrol.samsung.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/** Enciende la TV con un paquete mágico Wake-on-LAN. */
object WakeOnLan {

    fun parseMac(mac: String): ByteArray? {
        val parts = mac.trim().split(":", "-")
        if (parts.size != 6) return null
        return try {
            ByteArray(6) { i -> parts[i].toInt(16).toByte() }
        } catch (e: NumberFormatException) {
            null
        }
    }

    suspend fun send(mac: String, tvIp: String): Boolean = withContext(Dispatchers.IO) {
        val macBytes = parseMac(mac) ?: return@withContext false
        val payload = ByteArray(6 + 16 * 6)
        for (i in 0 until 6) payload[i] = 0xFF.toByte()
        for (i in 0 until 16) System.arraycopy(macBytes, 0, payload, 6 + i * 6, 6)

        val targets = linkedSetOf("255.255.255.255")
        val octets = tvIp.split(".")
        if (octets.size == 4) targets += "${octets[0]}.${octets[1]}.${octets[2]}.255"
        if (tvIp.isNotBlank()) targets += tvIp

        try {
            DatagramSocket().use { socket ->
                socket.broadcast = true
                repeat(3) {
                    for (target in targets) {
                        for (port in intArrayOf(9, 7)) {
                            socket.send(DatagramPacket(payload, payload.size, InetAddress.getByName(target), port))
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
