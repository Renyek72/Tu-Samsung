package com.tvcontrol.samsung.mirror

import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Servidor HTTP mínimo que entrega el flujo MPEG-TS en vivo a la TV.
 * Cada cliente tiene su cola; si la TV no da abasto se descartan fotogramas hasta el siguiente clave.
 */
class TsStreamServer(private val port: Int) {

    private class Client(val socket: Socket) {
        val queue = LinkedBlockingQueue<ByteArray>(120)

        @Volatile
        var waitKey = true

        @Volatile
        var alive = true
    }

    private val clients = CopyOnWriteArrayList<Client>()
    private var server: ServerSocket? = null

    @Volatile
    private var running = false

    /** Se invoca cuando un cliente nuevo empieza a recibir: conviene pedir un fotograma clave. */
    @Volatile
    var onClientConnected: (() -> Unit)? = null

    fun start() {
        val ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(port))
        server = ss
        running = true
        thread(name = "ts-accept", isDaemon = true) {
            while (running) {
                try {
                    val socket = ss.accept()
                    thread(name = "ts-client", isDaemon = true) { handle(socket) }
                } catch (e: IOException) {
                    if (!running) break
                }
            }
        }
    }

    fun stop() {
        running = false
        try {
            server?.close()
        } catch (e: IOException) {
            // ya cerrado
        }
        server = null
        for (c in clients) {
            c.alive = false
            try {
                c.socket.close()
            } catch (e: IOException) {
                // ya cerrado
            }
        }
        clients.clear()
    }

    fun broadcast(data: ByteArray, keyFrame: Boolean) {
        for (c in clients) {
            if (c.waitKey) {
                if (!keyFrame) continue
                c.waitKey = false
            }
            if (!c.queue.offer(data)) {
                c.queue.clear()
                c.waitKey = true
            }
        }
    }

    private fun handle(socket: Socket) {
        val client = Client(socket)
        try {
            socket.tcpNoDelay = true
            socket.soTimeout = 5000
            val reader = socket.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            val requestLine = reader.readLine() ?: return
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
            }
            val out = socket.getOutputStream()
            val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: video/mpeg\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n" +
                "transferMode.dlna.org: Streaming\r\n" +
                "contentFeatures.dlna.org: DLNA.ORG_OP=00;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000\r\n" +
                "Server: TvRemote/1.0\r\n\r\n"
            out.write(header.toByteArray(Charsets.ISO_8859_1))
            out.flush()
            if (requestLine.startsWith("HEAD")) return

            socket.soTimeout = 0
            clients.add(client)
            onClientConnected?.invoke()
            while (client.alive && running) {
                val chunk = client.queue.poll(1, TimeUnit.SECONDS)
                if (chunk != null) {
                    out.write(chunk)
                    out.flush()
                }
            }
        } catch (e: IOException) {
            // el cliente cerró la conexión
        } catch (e: InterruptedException) {
            // servicio detenido
        } finally {
            client.alive = false
            clients.remove(client)
            try {
                socket.close()
            } catch (e: IOException) {
                // ya cerrado
            }
        }
    }
}
