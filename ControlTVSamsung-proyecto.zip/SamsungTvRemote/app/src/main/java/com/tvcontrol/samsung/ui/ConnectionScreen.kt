package com.tvcontrol.samsung.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcontrol.samsung.TvViewModel

@Composable
fun ConnectionScreen(vm: TvViewModel, modifier: Modifier = Modifier) {
    val state by vm.connState.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Conexión con la TV", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        ConnectionBanner(vm, state)

        Button(
            onClick = { vm.scan() },
            enabled = !vm.scanning,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (vm.scanning) "Buscando…" else "Buscar TV en mi red") }

        vm.found.forEach { tv ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { vm.select(tv) }
                    .padding(12.dp),
            ) {
                Text(tv.name.ifBlank { "TV Samsung" }, fontWeight = FontWeight.SemiBold)
                Text(
                    listOf(tv.ip, tv.model).filter { it.isNotBlank() }.joinToString(" · "),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        OutlinedTextField(
            value = vm.ip,
            onValueChange = { vm.setIp(it) },
            label = { Text("IP de la TV (ej. 192.168.1.50)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = vm.mac,
            onValueChange = { vm.setMac(it) },
            label = { Text("MAC de la TV (para encenderla)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.connect() }, modifier = Modifier.weight(1f)) { Text("Conectar") }
            OutlinedButton(onClick = { vm.disconnect() }, modifier = Modifier.weight(1f)) { Text("Desconectar") }
        }

        OutlinedButton(
            onClick = { vm.forgetPairing() },
            enabled = vm.hasToken,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (vm.hasToken) "Olvidar emparejamiento" else "Sin emparejar") }

        Text(
            "Primera vez: la TV mostrará un aviso «¿Permitir?». Acéptalo con el control original. " +
                "La app guarda el permiso y no vuelve a preguntar.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "Fuera de casa: la TV solo acepta conexiones de su red local. Para controlarla por internet, " +
                "conecta el teléfono a tu red doméstica con una VPN (WireGuard, Tailscale…) y usa la IP local de la TV.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
