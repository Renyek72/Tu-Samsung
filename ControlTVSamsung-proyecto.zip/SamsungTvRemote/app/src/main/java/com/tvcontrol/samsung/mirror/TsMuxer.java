package com.tvcontrol.samsung.mirror;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/**
 * Empaqueta video H.264 (Annex B) en MPEG-TS para enviarlo por HTTP a la TV.
 * Un solo programa con una sola pista de video; sin audio.
 */
public final class TsMuxer {
    private static final int PMT_PID = 0x1000;
    private static final int VIDEO_PID = 0x0100;
    private static final long PTS_OFFSET = 90000L;          // 1 s de margen para que el PCR nunca sea negativo
    private static final long PTS_MASK = 0x1FFFFFFFFL;      // 33 bits
    private static final byte[] AUD = {0, 0, 0, 1, 0x09, (byte) 0xF0};

    private int ccPat;
    private int ccPmt;
    private int ccVideo;
    private byte[] codecConfig = new byte[0];
    private long basePtsUs = -1;

    /** SPS+PPS (Annex B) entregados por el codificador; se anteponen a cada fotograma clave. */
    public void setCodecConfig(byte[] config) {
        this.codecConfig = config.clone();
    }

    /**
     * @param frame    unidad de acceso H.264 en Annex B (con start codes)
     * @param ptsUs    marca de tiempo en microsegundos
     * @param keyFrame true si es un fotograma clave (IDR)
     * @return bytes TS (múltiplo de 188) listos para enviar
     */
    public byte[] muxFrame(byte[] frame, long ptsUs, boolean keyFrame) {
        if (basePtsUs < 0) {
            basePtsUs = ptsUs;
        }
        long pts = (((ptsUs - basePtsUs) * 9L) / 100L + PTS_OFFSET) & PTS_MASK;

        int cfgLen = keyFrame ? codecConfig.length : 0;
        int esLen = AUD.length + cfgLen + frame.length;
        byte[] pes = new byte[14 + esLen];
        pes[0] = 0;
        pes[1] = 0;
        pes[2] = 1;
        pes[3] = (byte) 0xE0;   // stream_id video
        pes[4] = 0;             // PES_packet_length = 0 (ilimitado, válido para video)
        pes[5] = 0;
        pes[6] = (byte) 0x80;
        pes[7] = (byte) 0x80;   // solo PTS
        pes[8] = 5;
        writePts(pes, 9, pts);
        int p = 14;
        System.arraycopy(AUD, 0, pes, p, AUD.length);
        p += AUD.length;
        if (cfgLen > 0) {
            System.arraycopy(codecConfig, 0, pes, p, cfgLen);
            p += cfgLen;
        }
        System.arraycopy(frame, 0, pes, p, frame.length);

        ByteArrayOutputStream out = new ByteArrayOutputStream(pes.length + pes.length / 180 * 4 + 1024);
        if (keyFrame) {
            writeSection(out, 0, patSection());
            writeSection(out, PMT_PID, pmtSection());
        }
        packetizeVideo(out, pes, pts, keyFrame);
        return out.toByteArray();
    }

    private void packetizeVideo(ByteArrayOutputStream out, byte[] pes, long pts, boolean key) {
        byte[] pkt = new byte[188];
        int offset = 0;
        boolean first = true;
        while (offset < pes.length) {
            int remaining = pes.length - offset;
            int maxPayload = first ? 176 : 184;     // el primero lleva campo de adaptación con PCR (8 bytes)
            int payloadLen = Math.min(remaining, maxPayload);
            int afTotal = 184 - payloadLen;         // bytes del campo de adaptación, incluido su byte de longitud

            pkt[0] = 0x47;
            pkt[1] = (byte) ((first ? 0x40 : 0x00) | ((VIDEO_PID >> 8) & 0x1F));
            pkt[2] = (byte) (VIDEO_PID & 0xFF);
            int afc = afTotal > 0 ? 3 : 1;
            pkt[3] = (byte) ((afc << 4) | ccVideo);
            ccVideo = (ccVideo + 1) & 0x0F;

            if (afTotal > 0) {
                pkt[4] = (byte) (afTotal - 1);
                if (afTotal >= 2) {
                    int flags = 0;
                    int stuffFrom = 6;
                    if (first) {
                        flags |= 0x10;              // PCR presente
                        if (key) {
                            flags |= 0x40;          // random access indicator
                        }
                        writePcr(pkt, 6, (pts - 9000L) & PTS_MASK);
                        stuffFrom = 12;
                    }
                    pkt[5] = (byte) flags;
                    for (int i = stuffFrom; i < 4 + afTotal; i++) {
                        pkt[i] = (byte) 0xFF;
                    }
                }
            }
            System.arraycopy(pes, offset, pkt, 4 + afTotal, payloadLen);
            out.write(pkt, 0, 188);
            offset += payloadLen;
            first = false;
        }
    }

    private void writeSection(ByteArrayOutputStream out, int pid, byte[] section) {
        byte[] pkt = new byte[188];
        Arrays.fill(pkt, (byte) 0xFF);
        int cc;
        if (pid == 0) {
            cc = ccPat;
            ccPat = (ccPat + 1) & 0x0F;
        } else {
            cc = ccPmt;
            ccPmt = (ccPmt + 1) & 0x0F;
        }
        pkt[0] = 0x47;
        pkt[1] = (byte) (0x40 | ((pid >> 8) & 0x1F));
        pkt[2] = (byte) (pid & 0xFF);
        pkt[3] = (byte) (0x10 | cc);
        pkt[4] = 0;                                  // pointer_field
        System.arraycopy(section, 0, pkt, 5, section.length);
        out.write(pkt, 0, 188);
    }

    private static byte[] patSection() {
        byte[] s = new byte[16];
        int[] head = {0x00, 0xB0, 0x0D, 0x00, 0x01, 0xC1, 0x00, 0x00, 0x00, 0x01, 0xF0, 0x00};
        for (int i = 0; i < head.length; i++) {
            s[i] = (byte) head[i];
        }
        putCrc(s, head.length);
        return s;
    }

    private static byte[] pmtSection() {
        byte[] s = new byte[21];
        int[] head = {0x02, 0xB0, 0x12, 0x00, 0x01, 0xC1, 0x00, 0x00, 0xE1, 0x00, 0xF0, 0x00,
                0x1B, 0xE1, 0x00, 0xF0, 0x00};
        for (int i = 0; i < head.length; i++) {
            s[i] = (byte) head[i];
        }
        putCrc(s, head.length);
        return s;
    }

    private static void putCrc(byte[] s, int len) {
        int crc = crc32Mpeg(s, len);
        s[len] = (byte) (crc >>> 24);
        s[len + 1] = (byte) (crc >>> 16);
        s[len + 2] = (byte) (crc >>> 8);
        s[len + 3] = (byte) crc;
    }

    private static int crc32Mpeg(byte[] data, int len) {
        int crc = 0xFFFFFFFF;
        for (int i = 0; i < len; i++) {
            crc ^= (data[i] & 0xFF) << 24;
            for (int b = 0; b < 8; b++) {
                crc = ((crc & 0x80000000) != 0) ? (crc << 1) ^ 0x04C11DB7 : (crc << 1);
            }
        }
        return crc;
    }

    private static void writePts(byte[] b, int o, long pts) {
        b[o] = (byte) (0x21 | (((pts >> 30) & 0x07) << 1));
        b[o + 1] = (byte) ((pts >> 22) & 0xFF);
        b[o + 2] = (byte) ((((pts >> 15) & 0x7F) << 1) | 1);
        b[o + 3] = (byte) ((pts >> 7) & 0xFF);
        b[o + 4] = (byte) (((pts & 0x7F) << 1) | 1);
    }

    private static void writePcr(byte[] b, int o, long base) {
        b[o] = (byte) (base >> 25);
        b[o + 1] = (byte) (base >> 17);
        b[o + 2] = (byte) (base >> 9);
        b[o + 3] = (byte) (base >> 1);
        b[o + 4] = (byte) (((base & 1) << 7) | 0x7E);
        b[o + 5] = 0;
    }
}
