package com.tvcontrol.samsung.net

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** Busca TVs Samsung en la red local: primero por SSDP y, si no hay respuesta, escaneando el puerto 8001. */
class TvDiscovery(private val context: Context, private val client: SamsungTvClient) {

    suspend fun scan(): List<TvInfo> = coroutineScope {
        suspend fun probe(hosts: Collection<String>): List<TvInfo> =
            hosts.map { ip -> async { client.fetchInfo(ip) } }.awaitAll().filterNotNull()

        // SSDP también lo contestan Chromecast, Roku, etc.; si ninguno es una Samsung, se escanea la subred.
        val viaSsdp = probe(ssdpHosts())
        if (viaSsdp.isNotEmpty()) viaSsdp else probe(subnetHosts())
    }

    private suspend fun ssdpHosts(durationMs: Long = 3000): Set<String> = withContext(Dispatchers.IO) {
        val wifi = context.applicationContext.getSystemService(WifiManager::class.java)
        val lock = wifi?.createMulticastLock("tvremote-ssdp")?.apply {
            setReferenceCounted(false)
            acquire()
        }
        val found = linkedSetOf<String>()
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 600
                val targets = listOf(
                    "urn:samsung.com:device:RemoteControlReceiver:1",
                    "urn:dial-multiscreen-org:service:dial:1",
                )
                val group = InetAddress.getByName("239.255.255.250")
                for (st in targets) {
                    val message = ("M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\n" +
                        "ST: $st\r\n\r\n").toByteArray()
                    socket.send(DatagramPacket(message, message.size, group, 1900))
                }
                val end = System.currentTimeMillis() + durationMs
                val buffer = ByteArray(2048)
                while (System.currentTimeMillis() < end) {
                    try {
                        val response = DatagramPacket(buffer, buffer.size)
                        socket.receive(response)
                        response.address.hostAddress?.let { found += it }
                    } catch (e: SocketTimeoutException) {
                        // seguir esperando hasta agotar el tiempo
                    }
                }
            }
        } catch (e: Exception) {
            // sin multicast disponible: se usará el escaneo de subred
        } finally {
            lock?.release()
        }
        found
    }

    private suspend fun subnetHosts(): List<String> = coroutineScope {
        val local = NetUtil.localIpv4(context) ?: return@coroutineScope emptyList()
        val parts = local.ip.split(".")
        if (parts.size != 4) return@coroutineScope emptyList()
        val base = "${parts[0]}.${parts[1]}.${parts[2]}."
        val all = (1..254).map { base + it }.filter { it != local.ip }
        all.chunked(64).flatMap { chunk ->
            chunk.map { ip -> async { if (portOpen(ip, 8001, 400)) ip else null } }
                .awaitAll()
                .filterNotNull()
        }
    }

    private suspend fun portOpen(ip: String, port: Int, timeoutMs: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket().use { it.connect(InetSocketAddress(ip, port), timeoutMs) }
            true
        } catch (e: Exception) {
            false
        }
    }
}
