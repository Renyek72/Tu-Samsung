package com.tvcontrol.samsung.net

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URI
import java.util.concurrent.TimeUnit

/** Le pide a la TV (receptor DLNA / UPnP AVTransport) que reproduzca una URL. */
class DlnaController(private val context: Context) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /** @return null si todo salió bien; si no, un mensaje de error para el usuario. */
    suspend fun playUrl(tvIp: String, streamUrl: String): String? {
        val control = findControlUrl(tvIp)
            ?: return "La TV no expone el receptor DLNA. Verifica que esté encendida y en la misma red Wi-Fi."
        soap(control, "Stop", "<InstanceID>0</InstanceID>")
        val setOk = soap(
            control,
            "SetAVTransportURI",
            "<InstanceID>0</InstanceID>" +
                "<CurrentURI>${esc(streamUrl)}</CurrentURI>" +
                "<CurrentURIMetaData>${esc(didl(streamUrl))}</CurrentURIMetaData>",
        )
        if (!setOk) return "La TV rechazó la dirección del stream."
        delay(800)
        val play = "<InstanceID>0</InstanceID><Speed>1</Speed>"
        if (!soap(control, "Play", play)) {
            delay(1500)
            if (!soap(control, "Play", play)) return "La TV no pudo reproducir el stream."
        }
        return null
    }

    suspend fun stop(tvIp: String) {
        val control = findControlUrl(tvIp) ?: return
        soap(control, "Stop", "<InstanceID>0</InstanceID>")
    }

    private suspend fun findControlUrl(tvIp: String): String? = withContext(Dispatchers.IO) {
        val descriptions = mutableListOf("http://$tvIp:9197/dmr")
        discoverRendererLocation(tvIp)?.let { if (it !in descriptions) descriptions += it }
        for (description in descriptions) {
            try {
                val xml = http.newCall(Request.Builder().url(description).build()).execute().use { r ->
                    if (r.isSuccessful) r.body?.string().orEmpty() else ""
                }
                val control = parseControlUrl(xml)
                if (control != null) return@withContext URI(description).resolve(control).toString()
            } catch (e: Exception) {
                // probar la siguiente descripción
            }
        }
        null
    }

    private fun parseControlUrl(xml: String): String? {
        val services = Regex("<service>.*?</service>", RegexOption.DOT_MATCHES_ALL).findAll(xml)
        for (service in services) {
            if (service.value.contains("AVTransport")) {
                val match = Regex("<controlURL>(.*?)</controlURL>", RegexOption.DOT_MATCHES_ALL).find(service.value)
                if (match != null) return match.groupValues[1].trim()
            }
        }
        return null
    }

    /** Busca por SSDP la descripción del MediaRenderer de esa TV (por si no usa el puerto 9197). */
    private fun discoverRendererLocation(tvIp: String): String? {
        val wifi = context.applicationContext.getSystemService(WifiManager::class.java)
        val lock = wifi?.createMulticastLock("tvremote-dlna")?.apply {
            setReferenceCounted(false)
            acquire()
        }
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 600
                val message = ("M-SEARCH * HTTP/1.1\r\n" +
                    "HOST: 239.255.255.250:1900\r\n" +
                    "MAN: \"ssdp:discover\"\r\n" +
                    "MX: 2\r\n" +
                    "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n").toByteArray()
                socket.send(DatagramPacket(message, message.size, InetAddress.getByName("239.255.255.250"), 1900))
                val end = System.currentTimeMillis() + 2500
                val buffer = ByteArray(2048)
                while (System.currentTimeMillis() < end) {
                    try {
                        val response = DatagramPacket(buffer, buffer.size)
                        socket.receive(response)
                        if (response.address.hostAddress == tvIp) {
                            val text = String(response.data, 0, response.length)
                            val location = Regex("(?im)^location:\\s*(\\S+)").find(text)
                            if (location != null) return location.groupValues[1]
                        }
                    } catch (e: SocketTimeoutException) {
                        // seguir esperando
                    }
                }
            }
        } catch (e: Exception) {
            // sin multicast
        } finally {
            lock?.release()
        }
        return null
    }

    private suspend fun soap(controlUrl: String, action: String, args: String): Boolean = withContext(Dispatchers.IO) {
        val body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
            "<s:Body><u:$action xmlns:u=\"$SERVICE\">$args</u:$action></s:Body></s:Envelope>"
        val request = Request.Builder()
            .url(controlUrl)
            .header("SOAPACTION", "\"$SERVICE#$action\"")
            .post(body.toRequestBody("text/xml; charset=utf-8".toMediaType()))
            .build()
        try {
            http.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false
        }
    }

    private fun didl(url: String): String =
        "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
            "<item id=\"0\" parentID=\"-1\" restricted=\"1\">" +
            "<dc:title>Pantalla del teléfono</dc:title>" +
            "<upnp:class>object.item.videoItem</upnp:class>" +
            "<res protocolInfo=\"http-get:*:video/mpeg:DLNA.ORG_OP=00;DLNA.ORG_CI=0;" +
            "DLNA.ORG_FLAGS=01700000000000000000000000000000\">${esc(url)}</res>" +
            "</item></DIDL-Lite>"

    private fun esc(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private companion object {
        const val SERVICE = "urn:schemas-upnp-org:service:AVTransport:1"
    }
}
