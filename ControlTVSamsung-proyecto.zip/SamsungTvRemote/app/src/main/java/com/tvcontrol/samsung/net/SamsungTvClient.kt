package com.tvcontrol.samsung.net

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

sealed interface ConnState {
    data object Disconnected : ConnState
    data object Connecting : ConnState
    data object WaitingApproval : ConnState
    data object Connected : ConnState
    data class Error(val message: String) : ConnState
}

data class TvInfo(
    val ip: String,
    val name: String,
    val model: String,
    val wifiMac: String,
    val powerState: String,
)

/**
 * Cliente del API de control remoto de las Samsung Smart TV con Tizen (2016 en adelante).
 *
 * - Control: WebSocket seguro en el puerto 8002 (con token) y, si falla, WebSocket 8001.
 * - Información y lanzamiento de apps: API REST en el puerto 8001.
 */
class SamsungTvClient(private val appName: String = "Control TV") {

    private val _state = MutableStateFlow<ConnState>(ConnState.Disconnected)
    val state: StateFlow<ConnState> = _state.asStateFlow()

    /** Se invoca cuando la TV entrega (o confirma) el token de emparejamiento. */
    @Volatile
    var onToken: ((String) -> Unit)? = null

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    // La TV usa un certificado autofirmado en el puerto 8002: este cliente solo se usa para la TV.
    private val wsClient: OkHttpClient = buildTrustAllClient()

    @Volatile
    private var socket: WebSocket? = null

    @Volatile
    private var generation = 0

    fun connect(ip: String, token: String?) {
        disconnect()
        val gen = ++generation
        _state.value = ConnState.Connecting
        open(ip, token, secure = true, gen = gen)
    }

    fun disconnect() {
        generation++
        socket?.close(1000, "bye")
        socket = null
        _state.value = ConnState.Disconnected
    }

    private fun open(ip: String, token: String?, secure: Boolean, gen: Int) {
        val name = Base64.encodeToString(appName.toByteArray(), Base64.NO_WRAP)
        val url = if (secure) {
            buildString {
                append("wss://").append(ip).append(":8002/api/v2/channels/samsung.remote.control?name=").append(name)
                if (!token.isNullOrEmpty()) append("&token=").append(token)
            }
        } else {
            "ws://$ip:8001/api/v2/channels/samsung.remote.control?name=$name"
        }
        val request = Request.Builder().url(url).build()
        socket = wsClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (gen != generation) return
                _state.value = ConnState.WaitingApproval
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen != generation) return
                val json = try {
                    JSONObject(text)
                } catch (e: Exception) {
                    return
                }
                when (json.optString("event")) {
                    "ms.channel.connect" -> {
                        val newToken = json.optJSONObject("data")?.optString("token").orEmpty()
                        if (newToken.isNotEmpty()) onToken?.invoke(newToken)
                        _state.value = ConnState.Connected
                    }
                    "ms.channel.unauthorized" ->
                        _state.value = ConnState.Error("La TV rechazó la conexión. Permítela en la TV (Ajustes > General > Administrador de dispositivos externos > Administrador de conexiones > Lista de dispositivos).")
                    "ms.channel.timeOut" ->
                        _state.value = ConnState.Error("La TV no recibió confirmación a tiempo. Acepta el aviso en la pantalla de la TV y vuelve a intentarlo.")
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (gen != generation) return
                if (_state.value !is ConnState.Error) _state.value = ConnState.Disconnected
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (gen != generation) return
                val current = _state.value
                if (secure && (current is ConnState.Connecting)) {
                    // TV antigua (2016-2017) sin 8002: probar el puerto 8001 sin TLS.
                    open(ip, token, secure = false, gen = gen)
                    return
                }
                _state.value = when (current) {
                    is ConnState.Connected -> ConnState.Error("Se perdió la conexión con la TV.")
                    is ConnState.Error -> current
                    else -> ConnState.Error("No se pudo conectar con la TV (${t.message ?: "sin respuesta"}). Verifica la IP y que esté encendida.")
                }
            }
        })
    }

    private fun send(json: JSONObject): Boolean = socket?.send(json.toString()) ?: false

    fun sendKey(code: String): Boolean = send(
        JSONObject()
            .put("method", "ms.remote.control")
            .put(
                "params",
                JSONObject()
                    .put("Cmd", "Click")
                    .put("DataOfCmd", code)
                    .put("Option", "false")
                    .put("TypeOfRemote", "SendRemoteKey"),
            ),
    )

    fun sendText(text: String): Boolean {
        val encoded = Base64.encodeToString(text.toByteArray(), Base64.NO_WRAP)
        return send(
            JSONObject()
                .put("method", "ms.remote.control")
                .put(
                    "params",
                    JSONObject()
                        .put("Cmd", encoded)
                        .put("DataOfCmd", "base64")
                        .put("TypeOfRemote", "SendInputString"),
                ),
        )
    }

    suspend fun fetchInfo(ip: String): TvInfo? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url("http://$ip:8001/api/v2/").build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    null
                } else {
                    val body = JSONObject(response.body?.string().orEmpty())
                    val dev = body.optJSONObject("device")
                    TvInfo(
                        ip = ip,
                        name = dev?.optString("name").orEmpty().ifEmpty { body.optString("name", "TV Samsung") },
                        model = dev?.optString("modelName").orEmpty(),
                        wifiMac = dev?.optString("wifiMac").orEmpty(),
                        powerState = dev?.optString("PowerState").orEmpty(),
                    )
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun launchApp(ip: String, appId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("http://$ip:8001/api/v2/applications/$appId")
                .post("".toRequestBody(null))
                .build()
            httpClient.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false
        }
    }

    private fun buildTrustAllClient(): OkHttpClient {
        val trustManager = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, arrayOf<TrustManager>(trustManager), SecureRandom())
        return OkHttpClient.Builder()
            .sslSocketFactory(sslContext.socketFactory, trustManager)
            .hostnameVerifier { _, _ -> true }
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
    }
}
