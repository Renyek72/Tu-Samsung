package com.tvcontrol.samsung

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.tvcontrol.samsung.mirror.ScreenMirrorService
import com.tvcontrol.samsung.ui.TvApp
import com.tvcontrol.samsung.ui.TvTheme

class MainActivity : ComponentActivity() {

    private val vm: TvViewModel by viewModels()

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val intent = Intent(this, ScreenMirrorService::class.java)
                    .putExtra(ScreenMirrorService.EXTRA_CODE, result.resultCode)
                    .putExtra(ScreenMirrorService.EXTRA_DATA, data)
                    .putExtra(ScreenMirrorService.EXTRA_TV_IP, vm.ip)
                ContextCompat.startForegroundService(this, intent)
            } else {
                vm.say("Se canceló el permiso de captura de pantalla.")
            }
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            TvTheme {
                TvApp(
                    vm = vm,
                    onStartMirror = ::startMirror,
                    onStopMirror = ::stopMirror,
                    onOpenCast = ::openCast,
                )
            }
        }
    }

    private fun startMirror() {
        if (vm.ip.isBlank()) {
            vm.say("Primero configura la TV en la pestaña «Conexión».")
            return
        }
        val manager = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun stopMirror() {
        startService(Intent(this, ScreenMirrorService::class.java).setAction(ScreenMirrorService.ACTION_STOP))
    }

    private fun openCast() {
        val options = listOf(
            Intent(Settings.ACTION_CAST_SETTINGS),
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
        )
        for (intent in options) {
            try {
                startActivity(intent)
                return
            } catch (e: Exception) {
                // probar la siguiente opción
            }
        }
        vm.say("Abre el panel rápido de Android y toca «Smart View» o «Transmitir».")
    }
}
