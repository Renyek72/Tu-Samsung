package com.tvcontrol.samsung.data

import android.content.Context

/** Guarda la TV configurada, su MAC (para encenderla) y el token de emparejamiento. */
class TvPrefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("tv_prefs", Context.MODE_PRIVATE)

    var ip: String
        get() = sp.getString("ip", "") ?: ""
        set(value) = sp.edit().putString("ip", value).apply()

    var mac: String
        get() = sp.getString("mac", "") ?: ""
        set(value) = sp.edit().putString("mac", value).apply()

    var token: String
        get() = sp.getString("token", "") ?: ""
        set(value) = sp.edit().putString("token", value).apply()

    var name: String
        get() = sp.getString("name", "") ?: ""
        set(value) = sp.edit().putString("name", value).apply()
}
