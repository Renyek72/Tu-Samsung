package com.tvcontrol.samsung.mirror

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.tvcontrol.samsung.MainActivity
import com.tvcontrol.samsung.R
import com.tvcontrol.samsung.net.DlnaController
import com.tvcontrol.samsung.net.NetUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Captura la pantalla (MediaProjection), la codifica en H.264, la sirve como MPEG-TS por HTTP
 * y le ordena a la TV que la reproduzca por DLNA.
 */
class ScreenMirrorService : Service() {

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var encoder: MediaCodec? = null
    private var server: TsStreamServer? = null
    private var drainThread: Thread? = null

    @Volatile
    private var running = false

    @Volatile
    private var stopping = false

    private var dlnaStarted = false
    private var tvIp = ""
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dlna by lazy { DlnaController(applicationContext) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            if (running) stopMirroring() else stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        try {
            startForegroundCompat()
        } catch (e: Exception) {
            MirrorState.status.value = MirrorStatus.Failed("No se pudo iniciar el servicio: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
        MirrorState.status.value = MirrorStatus.Starting

        val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        tvIp = intent.getStringExtra(EXTRA_TV_IP).orEmpty()
        if (data == null || code != Activity.RESULT_OK) {
            fail("No se obtuvo el permiso de captura de pantalla.")
            return START_NOT_STICKY
        }
        try {
            startMirroring(code, data)
        } catch (e: Exception) {
            fail("No se pudo iniciar la captura: ${e.message ?: e.javaClass.simpleName}")
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Transmisión de pantalla", NotificationManager.IMPORTANCE_LOW),
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenMirrorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_tv)
            .setContentTitle("Transmitiendo pantalla a la TV")
            .setContentText("Toca para abrir la app, o detén la transmisión desde aquí.")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Detener", stopIntent)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notification, type)
    }

    private fun startMirroring(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopMirroring()
            }
        }
        projectionCallback = callback
        // Obligatorio en Android 14+: registrar el callback antes de crear el VirtualDisplay.
        mp.registerCallback(callback, Handler(Looper.getMainLooper()))

        val metrics = resources.displayMetrics
        val (width, height) = encoderSize(metrics.widthPixels, metrics.heightPixels)

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            // Si la pantalla está estática, repetir el último fotograma para no cortar el stream.
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 500_000L)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        encoder = enc

        display = mp.createVirtualDisplay(
            "TvMirror", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null,
        )

        val srv = TsStreamServer(STREAM_PORT)
        srv.onClientConnected = {
            try {
                enc.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
            } catch (e: Exception) {
                // el codificador ya se detuvo
            }
        }
        srv.start()
        server = srv

        running = true
        val muxer = TsMuxer()
        drainThread = Thread({ drainLoop(enc, muxer, srv) }, "mirror-drain").also { it.start() }

        val phone = NetUtil.localIpv4(this)
        if (phone == null) {
            fail("El teléfono no está conectado a una red Wi-Fi.")
            return
        }
        val url = "http://${phone.ip}:$STREAM_PORT/screen.ts"
        dlnaStarted = true
        scope.launch {
            val error = dlna.playUrl(tvIp, url)
            if (stopping) return@launch
            if (error != null) {
                fail(error)
            } else {
                MirrorState.status.value = MirrorStatus.Streaming(url)
            }
        }
    }

    private fun drainLoop(enc: MediaCodec, muxer: TsMuxer, srv: TsStreamServer) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running) {
                val index = enc.dequeueOutputBuffer(info, 20_000)
                if (index < 0) continue
                try {
                    val buffer = enc.getOutputBuffer(index)
                    if (buffer != null && info.size > 0) {
                        buffer.position(info.offset)
                        buffer.limit(info.offset + info.size)
                        val bytes = ByteArray(info.size)
                        buffer.get(bytes)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            muxer.setCodecConfig(bytes)
                        } else {
                            val key = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                            srv.broadcast(muxer.muxFrame(bytes, info.presentationTimeUs, key), key)
                        }
                    }
                } finally {
                    try {
                        enc.releaseOutputBuffer(index, false)
                    } catch (e: IllegalStateException) {
                        // codificador detenido
                    }
                }
            }
        } catch (e: Exception) {
            // codificador detenido o cliente desconectado: el hilo termina sin tumbar la app
        }
    }

    private fun encoderSize(w: Int, h: Int): Pair<Int, Int> {
        val scale = minOf(1f, MAX_SIDE.toFloat() / maxOf(w, h))
        fun align(v: Float): Int = maxOf(16, (v / 16f).roundToInt() * 16)
        return align(w * scale) to align(h * scale)
    }

    private fun releaseAll() {
        running = false
        try {
            drainThread?.join(800)
        } catch (e: InterruptedException) {
            // seguir liberando
        }
        drainThread = null
        try {
            display?.release()
        } catch (e: Exception) {
            // ya liberado
        }
        display = null
        try {
            encoder?.stop()
        } catch (e: Exception) {
            // ya detenido
        }
        try {
            encoder?.release()
        } catch (e: Exception) {
            // ya liberado
        }
        encoder = null
        server?.stop()
        server = null
        val p = projection
        if (p != null) {
            projectionCallback?.let {
                try {
                    p.unregisterCallback(it)
                } catch (e: Exception) {
                    // ya sin registro
                }
            }
            try {
                p.stop()
            } catch (e: Exception) {
                // ya detenida
            }
        }
        projection = null
        projectionCallback = null
    }

    private fun stopMirroring() {
        if (stopping) return
        stopping = true
        val ip = tvIp
        val needStop = dlnaStarted
        releaseAll()
        if (needStop && ip.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch { dlna.stop(ip) }
        }
        MirrorState.status.value = MirrorStatus.Idle
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(message: String) {
        if (stopping) return
        stopping = true
        val ip = tvIp
        val needStop = dlnaStarted
        releaseAll()
        if (needStop && ip.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch { dlna.stop(ip) }
        }
        MirrorState.status.value = MirrorStatus.Failed(message)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (!stopping) {
            stopping = true
            releaseAll()
            if (MirrorState.status.value !is MirrorStatus.Failed) MirrorState.status.value = MirrorStatus.Idle
        }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.tvcontrol.samsung.STOP_MIRROR"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_TV_IP = "tv_ip"
        private const val CHANNEL_ID = "mirror"
        private const val NOTIF_ID = 42
        private const val STREAM_PORT = 8765
        private const val MAX_SIDE = 1280
        private const val BIT_RATE = 5_000_000
    }
}
