package com.tvcontrol.samsung.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcontrol.samsung.TvViewModel
import com.tvcontrol.samsung.net.Keys

private data class TvAppEntry(val name: String, val id: String)

// Los IDs pueden variar según región y modelo; si alguno no abre, usa el campo de ID personalizado.
private val Apps = listOf(
    TvAppEntry("Netflix", "11101200001"),
    TvAppEntry("YouTube", "111299001912"),
    TvAppEntry("Prime Video", "3201910019365"),
    TvAppEntry("Disney+", "3201901017640"),
    TvAppEntry("Spotify", "3201606009684"),
    TvAppEntry("Apple TV", "3201807016597"),
    TvAppEntry("Navegador web", "org.tizen.browser"),
)

@Composable
fun AppsScreen(vm: TvViewModel, modifier: Modifier = Modifier) {
    val state by vm.connState.collectAsStateWithLifecycle()
    var text by rememberSaveable { mutableStateOf("") }
    var customId by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ConnectionBanner(vm, state)

        SectionTitle("ABRIR APP EN LA TV")
        Apps.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { app ->
                    KeyButton(app.name, Modifier.weight(1f)) { vm.launchApp(app.id) }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        OutlinedTextField(
            value = customId,
            onValueChange = { customId = it },
            label = { Text("ID de otra app (opcional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(
            onClick = { if (customId.isNotBlank()) vm.launchApp(customId) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Abrir app por ID") }

        SectionTitle("TECLADO")
        Text(
            "Con un cuadro de texto activo en la TV (buscador, contraseña…), escribe aquí y envía.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
        )
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Texto para la TV") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    vm.sendText(text)
                    text = ""
                },
                modifier = Modifier.weight(1f),
            ) { Text("Enviar texto") }
            OutlinedButton(
                onClick = { vm.key(Keys.ENTER) },
                modifier = Modifier.weight(1f),
            ) { Text("OK / Enter") }
        }
    }
}
