package com.tvcontrol.samsung.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tvcontrol.samsung.TvViewModel
import com.tvcontrol.samsung.mirror.MirrorStatus

@Composable
fun MirrorScreen(
    vm: TvViewModel,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onOpenCast: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val status by vm.mirrorStatus.collectAsStateWithLifecycle()
    val active = status is MirrorStatus.Starting || status is MirrorStatus.Streaming

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Transmitir pantalla", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)

        // Opción 1: la de mejor calidad, la gestiona Android/Samsung
        InfoCard(
            title = "Opción 1 · Smart View / Cast (recomendada)",
            body = "Usa el espejo de pantalla nativo del teléfono (Miracast / Smart View). " +
                "Menor retraso y con audio. Acepta la solicitud que aparece en la TV.",
        ) {
            Button(onClick = onOpenCast, modifier = Modifier.fillMaxWidth()) {
                Text("Abrir ajustes de transmisión del teléfono")
            }
        }

        // Opción 2: transmisión por la red, desde la app
        InfoCard(
            title = "Opción 2 · Transmisión por red (desde esta app)",
            body = "La app captura la pantalla y se la envía a la TV por Wi-Fi mediante DLNA. " +
                "Solo video (sin audio) y con 2-5 segundos de retraso: sirve para fotos, presentaciones y apps, no para juegos.",
        ) {
            val (label, detail) = when (val s = status) {
                is MirrorStatus.Idle -> "Detenida" to ""
                is MirrorStatus.Starting -> "Iniciando…" to "Conectando con la TV."
                is MirrorStatus.Streaming -> "Transmitiendo" to "La TV debe mostrar tu pantalla en unos segundos."
                is MirrorStatus.Failed -> "Error" to s.message
            }
            Text(label, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            if (detail.isNotEmpty()) {
                Text(detail, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!active) {
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Iniciar transmisión") }
            } else {
                Button(
                    onClick = onStop,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("Detener transmisión") }
            }
        }

        Text(
            "Consejo: pon el teléfono en la orientación que quieras (vertical u horizontal) antes de iniciar. " +
                "El teléfono y la TV deben estar en la misma red Wi-Fi.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
        )
        OutlinedButton(onClick = { vm.key("KEY_SOURCE") }, modifier = Modifier.fillMaxWidth()) {
            Text("Cambiar fuente de la TV")
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Text(body, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}
