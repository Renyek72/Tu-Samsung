# Control TV Samsung (Android)

App Android para controlar una Smart TV Samsung por Wi-Fi/red: control remoto completo, teclado, apps, encendido
a distancia y transmisión de la pantalla del teléfono.

- **Compatible con:** Smart TV Samsung con Tizen (modelos de 2016 en adelante). No funciona con modelos anteriores a 2016.
- **Android:** 8.0 o superior.
- **Nada se envía a internet:** el teléfono habla directamente con la TV dentro de tu red.

---

## 1. Obtener el APK

No hay APK precompilado en este paquete: hay que compilarlo una vez. Elige una opción.

### Opción A · GitHub Actions (sin instalar nada)
1. Crea un repositorio en GitHub y sube **todo el contenido** de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions → Build APK → Run workflow** (también corre solo con cada *push*).
3. Al terminar, descarga el artefacto **ControlTVSamsung-apk**: dentro está `app-release.apk`.

### Opción B · Android Studio
1. Abre la carpeta del proyecto con Android Studio (Ladybug o más reciente).
2. Espera a que sincronice Gradle y pulsa **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. El APK queda en `app/build/outputs/apk/`.

### Opción C · Línea de comandos
Requiere JDK 17 y el Android SDK (plataforma 35) con `ANDROID_HOME` configurado:
```bash
./gradlew :app:assembleRelease
# APK: app/build/outputs/apk/release/app-release.apk
```

### Instalar en el teléfono
Copia el APK al teléfono, ábrelo y permite *«Instalar apps de origen desconocido»* para tu gestor de archivos.
El APK de *release* viene firmado con la clave de depuración: sirve para uso personal, no para Google Play.

---

## 2. Preparar la TV (una sola vez)

Los nombres de los menús cambian según el año y el modelo.

1. La TV y el teléfono deben estar en **la misma red Wi-Fi/LAN**.
2. Para poder **encenderla** desde la app: *Ajustes → General → Red → Configuración de experto →* activa
   **«Encender con móvil»** (Power On with Mobile). Si tu TV lo permite, déjala conectada a la red en reposo.
3. Si la TV rechaza la conexión: *Ajustes → General → Administrador de dispositivos externos → Administrador de
   conexiones →* revisa que el acceso de dispositivos esté en **Aceptar** o **Pedir confirmación**.

## 3. Primer uso

1. Abre la app → pestaña **Conexión** → **Buscar TV en mi red**. Si hay una sola TV, se conecta sola; si no, elige
   una de la lista. También puedes escribir la IP a mano (la ves en *Ajustes → General → Red → Estado de red*).
2. La TV mostrará un aviso **«¿Permitir?»**: acéptalo con el control original. La app guarda el permiso (token) y
   no vuelve a preguntar.
3. En la franja superior debe verse **Conectado · nombre de la TV**. Ya puedes usar la pestaña **Control**.

---

## 4. Funciones

### Pestaña Control (control remoto completo)
| Bloque | Teclas |
|---|---|
| Encendido y entradas | ⏻ Encender/Apagar, Fuente, HDMI, TV |
| Navegación | ▲ ▼ ◀ ▶ (mantener pulsado repite), OK, Atrás, Inicio, Salir |
| Volumen / Canales | VOL +/−, Silencio, CH +/−, Lista de canales |
| Menús | Menú, Info, Guía, Tools |
| Reproducción | Retroceder, Play, Pausa, Stop, Avanzar, Grabar |
| Teclas de color | Rojo, Verde, Amarillo, Azul |
| Números | 0–9, Canal anterior, Subtítulos |
| Otros | Lista de apps, Apagado automático, Tamaño de imagen |
| Panel táctil | Desliza para mover el cursor, toca para OK |

Cada pulsación vibra levemente. **Encender:** si la TV está apagada, el botón ⏻ envía un paquete *Wake-on-LAN* a la
MAC guardada y se conecta en cuanto la TV responde (hasta ~30 s). La MAC se detecta sola la primera vez que te
conectas con la TV encendida; también puedes escribirla en **Conexión**.

### Pestaña Apps
- Abre Netflix, YouTube, Prime Video, Disney+, Spotify, Apple TV y el navegador de la TV.
- Los IDs de las apps pueden variar según región/modelo: si alguna no abre, escribe su ID en **«ID de otra app»**.
- **Teclado:** con un cuadro de texto activo en la TV (buscador, contraseña…), escribe en el teléfono y pulsa
  **Enviar texto**.

### Pestaña Pantalla (transmitir la pantalla del teléfono)
- **Opción 1 · Smart View / Cast (recomendada):** abre los ajustes de transmisión del teléfono (Miracast/Smart View).
  Mejor calidad, menos retraso y con audio. Es la función nativa de Android/Samsung.
- **Opción 2 · Transmisión por red (desde la app):** captura la pantalla, la codifica en H.264 y se la envía a la
  TV por DLNA. **Solo video, sin audio, con 2–5 s de retraso** — pensada para fotos, presentaciones y apps, no para
  juegos. Gira el teléfono a la orientación deseada *antes* de iniciar. Aparece una notificación para detenerla.

### Controlar la TV por internet (fuera de casa)
La TV solo acepta conexiones de su red local, así que **no se puede apuntar directamente a ella desde internet**
(abrir puertos del router sería inseguro). La forma correcta es una **VPN** hacia tu red de casa (WireGuard,
Tailscale, la VPN de tu router…): con la VPN activa, el teléfono “está” en tu red y la app funciona igual usando la
IP local de la TV. La transmisión de pantalla fuera de casa depende del ancho de banda de la VPN.

---

## 5. Solución de problemas

| Síntoma | Qué hacer |
|---|---|
| «No encontré ninguna TV» | TV encendida y en la misma red; desactiva el aislamiento de clientes del Wi-Fi/«red de invitados»; escribe la IP a mano. |
| «Acepta el aviso en la TV» y no pasa nada | Mira la pantalla de la TV y acepta con el control original. Si lo rechazaste: Conexión → *Olvidar emparejamiento* y reintenta. |
| Los botones no responden | Conexión → *Conectar*. Si la TV cambió de IP, búscala de nuevo o fija una IP reservada en el router. |
| No enciende la TV | Activa «Encender con móvil»; comprueba la MAC; algunas TVs solo se despiertan por cable (usa la MAC de Ethernet). |
| Transmisión por red: pantalla negra en la TV | Acepta cualquier aviso de «dispositivo multimedia» que muestre la TV; usa la Opción 1 si tu modelo no admite el flujo. |
| La app de la TV no abre | Revisa que esté instalada; prueba con su ID en «ID de otra app». |

## 6. Límites conocidos

- Las teclas y apps dependen del modelo y la región de la TV; los códigos usados son los estándar de Samsung.
- La transmisión por red no incluye audio y tiene retraso; para audio y baja latencia usa Smart View/Miracast.
- Android 14+ pide elegir *pantalla completa* o *una app* al compartir; la app necesita permiso de notificaciones para
  mostrar el aviso de transmisión.

---

## 7. Detalles técnicos (para quien quiera modificar)

- **Control:** WebSocket `wss://TV:8002/api/v2/channels/samsung.remote.control` (con token; cae a `ws://TV:8001`),
  comandos `ms.remote.control` / `SendRemoteKey` y `SendInputString`. La TV usa un certificado autofirmado, por eso
  el cliente de la TV acepta ese certificado (solo se usa para esa conexión local).
- **Info y apps:** REST en `http://TV:8001/api/v2/` y `POST /api/v2/applications/{id}`.
- **Encendido:** paquete mágico Wake-on-LAN (UDP 9/7) a broadcast y a la subred.
- **Descubrimiento:** SSDP (`urn:samsung.com:device:RemoteControlReceiver:1`); si falla, escaneo del puerto 8001.
- **Pantalla por red:** `MediaProjection` → `MediaCodec` H.264 → muxer MPEG-TS propio (`TsMuxer.java`) → servidor HTTP
  `:8765/screen.ts` → `SetAVTransportURI` + `Play` (UPnP/DLNA AVTransport) en la TV.
- **Stack:** Kotlin, Jetpack Compose (Material 3), OkHttp, coroutines. `minSdk 26`, `targetSdk 35`.
